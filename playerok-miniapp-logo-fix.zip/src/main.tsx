import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Gamepad2, Gift, LockKeyhole, Sparkles, UserRound, Search, ChevronDown,
  Gem, TrendingUp, Activity, Wallet, ShoppingBag, ArrowUpRight, X,
  ExternalLink, ShieldCheck, Moon, Sun, ArrowLeft, Plus, Trash2,
  ImagePlus, CheckCircle2, Upload, UserRoundCheck, Globe2
} from 'lucide-react';
import './style.css';

type Tab = 'games' | 'market' | 'gifts' | 'event' | 'profile' | 'admin';
type Lang = 'EN' | 'RU';
type Sort = 'featured' | 'low' | 'high';
type Theme = 'light' | 'dark';
type TelegramUser = {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  photo_url?: string;
  is_premium?: boolean;
};
type GiftItem = {
  id: string;
  collection: string;
  number: number;
  model: string;
  modelRarity: string;
  backdrop: string;
  backdropRarity: string;
  symbol: string;
  symbolRarity: string;
  image: string;
  source: string;
  serial: string;
};

declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        initData?: string;
        initDataUnsafe?: { user?: TelegramUser };
        ready?: () => void;
        expand?: () => void;
        colorScheme?: 'light' | 'dark';
        setHeaderColor?: (color: string) => void;
        setBackgroundColor?: (color: string) => void;
      };
    };
  }
}

const STORAGE_KEY = 'playerok.catalog.v3';
const THEME_KEY = 'playerok.theme';
const botUrl = 'https://t.me/Playerok_Guarantor_Bot';

// Коллекционные подарки Telegram. Все изображения ведут на публичные NFT-превью Fragment.
const initialGifts: GiftItem[] = [
  {
    id: 'cookie-heart-3865', collection: 'Cookie Heart', number: 3865,
    model: 'Toasted', modelRarity: '1%', backdrop: 'Aquamarine', backdropRarity: '2%',
    symbol: 'Red Deer', symbolRarity: '0.2%',
    image: 'https://nft.fragment.com/gift/cookieheart-3865.webp',
    source: 'https://t.me/nft/CookieHeart-3865', serial: 'CookieHeart-3865'
  },
  {
    id: 'jelly-bunny-12779', collection: 'Jelly Bunny', number: 12779,
    model: 'Spring Day', modelRarity: '0.4%', backdrop: 'Electric Purple', backdropRarity: '0.83%',
    symbol: 'Spider Web', symbolRarity: '0.55%',
    image: 'https://nft.fragment.com/gift/jellybunny-12779.webp',
    source: 'https://t.me/nft/JellyBunny-12779', serial: 'JellyBunny-12779'
  },
  {
    id: 'durovs-cap-1361', collection: "Durov's Cap", number: 1361,
    model: 'Macintosh', modelRarity: '2.43%', backdrop: 'Azure Blue', backdropRarity: '1.95%',
    symbol: 'Cocktail', symbolRarity: '0.99%',
    image: 'https://nft.fragment.com/gift/durovscap-1361.webp',
    source: 'https://t.me/nft/DurovsCap-1361', serial: 'DurovsCap-1361'
  },
  {
    id: 'jelly-bunny-5286', collection: 'Jelly Bunny', number: 5286,
    model: 'Firefruit', modelRarity: '0.51%', backdrop: 'Lemongrass', backdropRarity: '1.84%',
    symbol: 'Rocket', symbolRarity: '0.48%',
    image: 'https://nft.fragment.com/gift/jellybunny-5286.webp',
    source: 'https://t.me/nft/JellyBunny-5286', serial: 'JellyBunny-5286'
  },
  {
    id: 'plushpepe-96', collection: 'Plush Pepe', number: 96,
    model: 'Princess', modelRarity: '2.1%', backdrop: 'Grape', backdropRarity: '2.05%',
    symbol: 'Toilet', symbolRarity: '0.5%',
    image: 'https://nft.fragment.com/gift/plushpepe-96.webp',
    source: 'https://t.me/nft/PlushPepe-96', serial: 'PlushPepe-96'
  }
];

const nav: { id: Exclude<Tab, 'admin'>; label: string; ru: string; icon: typeof Gamepad2 }[] = [
  { id: 'games', label: 'Games', ru: 'Игры', icon: Gamepad2 },
  { id: 'market', label: 'Market', ru: 'Маркет', icon: Gift },
  { id: 'gifts', label: 'My gifts', ru: 'Мои подарки', icon: LockKeyhole },
  { id: 'event', label: 'Event', ru: 'События', icon: Sparkles },
  { id: 'profile', label: 'Profile', ru: 'Профиль', icon: UserRound }
];

const copy = {
  EN: {
    games: 'Games are unavailable', gamesSub: 'Available games will appear here.', market: 'Telegram gifts',
    marketSub: 'Collectible Telegram gifts', my: 'My gifts', mySub: 'Your gifts, offers and purchase history in one place.',
    event: 'Events are unavailable', eventSub: 'New events and special offers will appear here.', profile: 'Profile',
    balance: 'BALANCE', spent: 'SPENT', purchases: 'PURCHASES', language: 'LANGUAGE', add: 'Add funds',
    fundSub: 'Deposits and withdrawals are currently unavailable.', search: 'Search gifts', featured: 'Featured',
    low: 'Lowest number', high: 'Highest number', listed: 'GIFTS IN CATALOG', floor: 'LOWEST NUMBER', volume: 'COLLECTIONS',
    openNumbers: 'Gift numbers', openDeals: 'Gift collections', unavailable: 'Unavailable', retry: 'Retry',
    offers: 'Offers', history: 'History', empty: 'Items could not be loaded. Try again later.', marketButton: 'Go to market',
    model: 'MODEL', backdrop: 'BACKGROUND', symbol: 'PATTERN', collection: 'COLLECTION',
    bot: 'Open Telegram bot', gamesInfo: 'This section is currently empty.',
    telegramConnect: 'Open this app from Telegram to show your profile.', connect: 'Open Telegram bot',
    account: 'TELEGRAM ACCOUNT', connected: 'Telegram profile connected', notConnected: 'Telegram profile not found',
    premium: 'TELEGRAM PREMIUM', admin: 'Manage catalog', adminTitle: 'Admin panel', adminSub: 'Add and remove collectible gifts from the catalog.',
    localOnly: 'Changes are saved in this browser only. To publish one shared catalog for all visitors, connect a database.',
    addGift: 'Add a gift', collectionName: 'Gift collection', number: 'Gift number', modelName: 'Model', modelRarity: 'Model rarity',
    background: 'Background', backgroundRarity: 'Background rarity', pattern: 'Pattern', patternRarity: 'Pattern rarity',
    imageUrl: 'Image URL', nftUrl: 'NFT link', saveGift: 'Add to market', catalogList: 'Catalog items', delete: 'Delete',
    added: 'Gift added to catalog', removed: 'Gift removed', invalid: 'Fill in collection, number, model, background, pattern and image URL.',
    openNft: 'View on Telegram', photo: 'Telegram avatar', notInTelegram: 'Not opened from Telegram',
    dark: 'Dark theme', light: 'Light theme', back: 'Back', id: 'TELEGRAM ID', username: 'USERNAME',
    userName: 'NAME', total: 'ITEMS'
  },
  RU: {
    games: 'Игры недоступны', gamesSub: 'Здесь появятся доступные игры.', market: 'Подарки Telegram',
    marketSub: 'Коллекционные подарки Telegram', my: 'Мои подарки', mySub: 'Подарки, предложения и история покупок в одном месте.',
    event: 'События недоступны', eventSub: 'Здесь появятся события и специальные предложения.', profile: 'Профиль',
    balance: 'БАЛАНС', spent: 'ПОТРАЧЕНО', purchases: 'ПОКУПКИ', language: 'ЯЗЫК', add: 'Пополнить баланс',
    fundSub: 'Пополнение и вывод средств пока недоступны.', search: 'Поиск подарков', featured: 'Рекомендуемые',
    low: 'Сначала меньший номер', high: 'Сначала больший номер', listed: 'ПОДАРКОВ В КАТАЛОГЕ', floor: 'МИНИМАЛЬНЫЙ НОМЕР', volume: 'КОЛЛЕКЦИИ',
    openNumbers: 'Номера подарков', openDeals: 'Коллекции подарков', unavailable: 'Недоступно', retry: 'Повторить',
    offers: 'Предложения', history: 'История', empty: 'Не удалось загрузить данные. Попробуйте позже.', marketButton: 'Перейти в маркет',
    model: 'МОДЕЛЬ', backdrop: 'ФОН', symbol: 'УЗОР', collection: 'КОЛЛЕКЦИЯ',
    bot: 'Открыть Telegram-бота', gamesInfo: 'Раздел пока пуст.',
    telegramConnect: 'Открой приложение через Telegram, чтобы увидеть свой профиль.', connect: 'Открыть Telegram-бота',
    account: 'АККАУНТ TELEGRAM', connected: 'Профиль Telegram подключён', notConnected: 'Профиль Telegram не найден',
    premium: 'TELEGRAM PREMIUM', admin: 'Управление каталогом', adminTitle: 'Панель администратора', adminSub: 'Добавление и удаление коллекционных подарков.',
    localOnly: 'Изменения сохраняются только в этом браузере. Для единого каталога у всех посетителей подключи базу данных.',
    addGift: 'Добавить подарок', collectionName: 'Коллекция подарка', number: 'Номер подарка', modelName: 'Модель', modelRarity: 'Редкость модели',
    background: 'Фон', backgroundRarity: 'Редкость фона', pattern: 'Узор', patternRarity: 'Редкость узора',
    imageUrl: 'Ссылка на изображение', nftUrl: 'Ссылка на NFT', saveGift: 'Добавить в маркет', catalogList: 'Подарки в каталоге', delete: 'Удалить',
    added: 'Подарок добавлен в каталог', removed: 'Подарок удалён', invalid: 'Заполни коллекцию, номер, модель, фон, узор и ссылку на изображение.',
    openNft: 'Открыть в Telegram', photo: 'Аватар Telegram', notInTelegram: 'Приложение открыто не из Telegram',
    dark: 'Тёмная тема', light: 'Светлая тема', back: 'Назад', id: 'TELEGRAM ID', username: 'ИМЯ ПОЛЬЗОВАТЕЛЯ',
    userName: 'ИМЯ', total: 'ЛОТОВ'
  }
};

function loadCatalog(): GiftItem[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return initialGifts;
    const parsed: unknown = JSON.parse(stored);
    if (Array.isArray(parsed)) return parsed as GiftItem[];
  } catch (error) {
    console.warn('Could not read the saved catalog:', error);
  }
  return initialGifts;
}

function getTelegramUser(): TelegramUser | null {
  const user = window.Telegram?.WebApp?.initDataUnsafe?.user;
  return user && typeof user.id === 'number' ? user : null;
}

function App() {
  const [tab, setTab] = useState<Tab>('games');
  const [lang, setLang] = useState<Lang>(() => {
    const tgLang = window.Telegram?.WebApp?.initDataUnsafe?.user?.language_code?.toLowerCase();
    return tgLang?.startsWith('ru') ? 'RU' : 'EN';
  });
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem(THEME_KEY);
    return saved === 'dark' ? 'dark' : 'light';
  });
  const [telegramUser, setTelegramUser] = useState<TelegramUser | null>(() => getTelegramUser());
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState<Sort>('featured');
  const [sub, setSub] = useState<'gifts' | 'offers' | 'history'>('gifts');
  const [langOpen, setLangOpen] = useState(false);
  const [catalog, setCatalog] = useState<GiftItem[]>(loadCatalog);
  const [toast, setToast] = useState('');
  const [giftForm, setGiftForm] = useState({
    collection: '', number: '', model: '', modelRarity: '', backdrop: '', backdropRarity: '',
    symbol: '', symbolRarity: '', image: '', source: ''
  });
  const t = copy[lang];

  useEffect(() => {
    const webApp = window.Telegram?.WebApp;
    webApp?.ready?.();
    webApp?.expand?.();
    const user = getTelegramUser();
    if (user) {
      setTelegramUser(user);
      if (user.language_code?.toLowerCase().startsWith('ru')) setLang('RU');
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(catalog));
  }, [catalog]);

  useEffect(() => {
    localStorage.setItem(THEME_KEY, theme);
    document.documentElement.dataset.theme = theme;
    document.body.dataset.theme = theme;
    const color = theme === 'dark' ? '#171a24' : '#f4f7fc';
    window.Telegram?.WebApp?.setHeaderColor?.(theme === 'dark' ? '#171a24' : '#ffffff');
    window.Telegram?.WebApp?.setBackgroundColor?.(color);
  }, [theme]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = catalog.filter(g => [g.collection, g.number, g.model, g.backdrop, g.symbol].join(' ').toLowerCase().includes(q));
    if (sort === 'low') list = [...list].sort((a, b) => a.number - b.number);
    if (sort === 'high') list = [...list].sort((a, b) => b.number - a.number);
    return list;
  }, [catalog, query, sort]);

  const go = (next: Tab) => {
    setTab(next);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const showToast = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(''), 2600);
  };
  const updateForm = (key: keyof typeof giftForm, value: string) => setGiftForm(old => ({ ...old, [key]: value }));
  const addGift = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const required = ['collection', 'number', 'model', 'backdrop', 'symbol', 'image'] as const;
    if (required.some(key => !giftForm[key].trim()) || !Number.isSafeInteger(Number(giftForm.number))) {
      showToast(t.invalid); return;
    }
    let imageUrl: URL;
    try { imageUrl = new URL(giftForm.image.trim()); } catch { showToast(t.invalid); return; }
    if (!['https:', 'http:'].includes(imageUrl.protocol)) { showToast(t.invalid); return; }
    let source = giftForm.source.trim();
    if (source) {
      try { const u = new URL(source); if (!['https:', 'http:'].includes(u.protocol)) throw new Error('URL'); }
      catch { showToast(t.invalid); return; }
    }
    const number = Number(giftForm.number);
    const serial = `${giftForm.collection.replace(/[^a-z0-9]/gi, '')}-${number}`;
    const item: GiftItem = {
      id: `gift-${Date.now()}-${number}`, collection: giftForm.collection.trim(), number,
      model: giftForm.model.trim(), modelRarity: giftForm.modelRarity.trim() || '—',
      backdrop: giftForm.backdrop.trim(), backdropRarity: giftForm.backdropRarity.trim() || '—',
      symbol: giftForm.symbol.trim(), symbolRarity: giftForm.symbolRarity.trim() || '—',
      image: imageUrl.href, source: source || `https://t.me/nft/${serial}`, serial
    };
    setCatalog(old => [item, ...old]);
    setGiftForm({ collection: '', number: '', model: '', modelRarity: '', backdrop: '', backdropRarity: '', symbol: '', symbolRarity: '', image: '', source: '' });
    showToast(t.added);
  };
  const deleteGift = (id: string) => {
    setCatalog(old => old.filter(g => g.id !== id));
    showToast(t.removed);
  };
  const exportCatalog = () => {
    const blob = new Blob([JSON.stringify(catalog, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url; anchor.download = 'playerok-catalog.json'; anchor.click();
    URL.revokeObjectURL(url);
  };
  const importCatalog = (file?: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        if (!Array.isArray(parsed) || !parsed.every(g => g && typeof g.collection === 'string' && typeof g.image === 'string')) throw new Error('Invalid catalog');
        setCatalog(parsed as GiftItem[]); showToast(t.added);
      } catch { showToast(t.invalid); }
    };
    reader.readAsText(file);
  };
  const fullName = telegramUser ? [telegramUser.first_name, telegramUser.last_name].filter(Boolean).join(' ') : '';
  const initials = fullName ? fullName.slice(0, 1).toUpperCase() : 'P';

  return <div className="app-shell" data-theme={theme}>
    <header className="topbar">
      <button className="brand" onClick={() => go('games')} aria-label="Playerok home">
        <img className="brand-symbol" src="/playerok-symbol.png" alt="Playerok" />
        <img className="brand-wordmark" src="/playerok-wordmark.png" alt="Playerok" />
      </button>
      <div className="header-actions">
        <a className="bot-link" href={botUrl} target="_blank" rel="noreferrer">@Playerok_Guarantor_Bot <ExternalLink size={12}/></a>
        <button className="theme-toggle" onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')} aria-label={theme === 'light' ? t.dark : t.light} title={theme === 'light' ? t.dark : t.light}>
          {theme === 'light' ? <Moon size={17}/> : <Sun size={17}/>}
        </button>
        <div className="lang-wrap">
          <button className="lang-button" onClick={() => setLangOpen(!langOpen)}>{lang}<ChevronDown size={15}/></button>
          {langOpen && <div className="lang-menu">
            <button onClick={() => { setLang('EN'); setLangOpen(false); }}>English</button>
            <button onClick={() => { setLang('RU'); setLangOpen(false); }}>Русский</button>
          </div>}
        </div>
      </div>
    </header>

    <main className="main-content">
      {tab === 'games' && <section className="empty-hero panel">
        <div className="hero-icon"><Gamepad2 size={29}/></div>
        <span className="section-kicker">PLAYEROK</span>
        <h1>{t.games}</h1><p>{t.gamesSub}</p>
        <button className="primary-btn" onClick={() => go('market')}>{t.marketButton}</button>
      </section>}

      {tab === 'market' && <section className="market-page">
        <div className="market-hero panel">
          <div className="banner-art">
            <div className="banner-shine"/><div className="banner-caption"><small>PLAYEROK MARKET</small><strong>Buy <em>&</em><br/>Sell</strong><span>GIFTS · ITEMS · COLLECTIBLES</span></div>
            <div className="banner-gift">✦</div><span className="banner-star">✦</span>
          </div>
          <div className="market-heading">
            <div><span className="eyebrow">PLAYEROK MARKET</span><h1>{t.market}</h1><p>{t.marketSub}</p></div>
            <div className="gem-icon"><Gem size={22}/></div>
          </div>
          <div className="stats-grid">
            <div className="stat"><Activity/><small>{t.listed}</small><b>{catalog.length}</b></div>
            <div className="stat"><Gem/><small>{t.floor}</small><b>{catalog.length ? `#${Math.min(...catalog.map(g => g.number)).toLocaleString('en-US')}` : '—'}</b></div>
            <div className="stat"><TrendingUp/><small>{t.volume}</small><b>{new Set(catalog.map(g => g.collection)).size}</b></div>
          </div>
        </div>

        <div className="quick-actions">
          <button onClick={() => document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' })}>{t.openNumbers}<ArrowUpRight size={15}/></button>
          <button onClick={() => { setQuery('Jelly Bunny'); document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' }); }}>{t.openDeals}<ArrowUpRight size={15}/></button>
        </div>

        <section className="catalog panel" id="catalog">
          <div className="catalog-title"><div><span className="eyebrow">COLLECTIBLES</span><h2>{lang === 'EN' ? 'Featured gifts' : 'Популярные подарки'}</h2></div><span className="count-pill">{filtered.length} {t.total}</span></div>
          <div className="searchbox"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder={t.search}/>{query && <button onClick={() => setQuery('')} aria-label="Clear search"><X size={16}/></button>}</div>
          <div className="sort-tabs">
            <button className={sort === 'featured' ? 'active' : ''} onClick={() => setSort('featured')}>{t.featured}</button>
            <button className={sort === 'low' ? 'active' : ''} onClick={() => setSort('low')}>{t.low}</button>
            <button className={sort === 'high' ? 'active' : ''} onClick={() => setSort('high')}>{t.high}</button>
          </div>
          <div className="gift-grid">
            {filtered.map(g => <article className="gift-card" key={g.id}>
              <div className="gift-art"><img src={g.image} alt={`${g.collection} #${g.number}`} loading="lazy" onError={e => { e.currentTarget.style.display = 'none'; e.currentTarget.parentElement?.classList.add('image-error'); }}/>
                <span className="serial-ribbon">#{g.number.toLocaleString('en-US')}</span>
              </div>
              <div className="gift-info">
                <div className="gift-title-row"><div className="gift-name">{g.collection}</div><span className="gift-number">#{g.number.toLocaleString('en-US')}</span></div>
                <div className="attribute-list">
                  <div className="attribute"><small>{t.model}</small><b>{g.model}</b><em>{g.modelRarity}</em></div>
                  <div className="attribute"><small>{t.backdrop}</small><b><i className={`backdrop-dot ${g.backdrop.toLowerCase().replace(/ /g, '-')}`}/>{g.backdrop}</b><em>{g.backdropRarity}</em></div>
                  <div className="attribute"><small>{t.symbol}</small><b>{g.symbol}</b><em>{g.symbolRarity}</em></div>
                </div>
                <div className="gift-card-bottom"><a href={g.source} target="_blank" rel="noreferrer">{t.openNft} <ExternalLink size={12}/></a><span className="unavailable"><ShoppingBag size={14}/>{t.unavailable}</span></div>
              </div>
            </article>)}
          </div>
          {filtered.length === 0 && <div className="no-results">{lang === 'EN' ? 'Nothing found' : 'Ничего не найдено'}</div>}
        </section>
      </section>}

      {tab === 'gifts' && <section className="my-page">
        <div className="page-heading panel"><div><span className="eyebrow">PLAYEROK ACCOUNT</span><h1>{t.my}</h1><p>{t.mySub}</p></div><div className="heading-icon"><LockKeyhole size={22}/></div></div>
        <div className="subtabs">
          <button className={sub === 'gifts' ? 'selected' : ''} onClick={() => setSub('gifts')}>{lang === 'EN' ? 'Gifts' : 'Подарки'}</button>
          <button className={sub === 'offers' ? 'selected' : ''} onClick={() => setSub('offers')}>{t.offers}</button>
          <button className={sub === 'history' ? 'selected' : ''} onClick={() => setSub('history')}>{t.history}</button>
        </div>
        <div className="error-box">{t.empty}</div><button className="retry-btn" disabled>{t.retry}</button>
      </section>}

      {tab === 'event' && <section className="empty-hero panel"><div className="hero-icon"><Sparkles size={29}/></div><span className="section-kicker">PLAYEROK EVENTS</span><h1>{t.event}</h1><p>{t.eventSub}</p><button className="primary-btn" disabled>{t.unavailable}</button></section>}

      {tab === 'profile' && <section className="profile-page">
        <div className="profile-card panel">
          <div className="profile-head"><div><span className="eyebrow">{t.account}</span><h1>{t.profile}</h1></div><div className="heading-icon"><Wallet size={22}/></div></div>
          {telegramUser ? <>
            <div className="telegram-status connected"><CheckCircle2 size={15}/>{t.connected}</div>
            <div className="user-row">
              {telegramUser.photo_url ? <img className="avatar avatar-photo" src={telegramUser.photo_url} alt={t.photo} referrerPolicy="no-referrer" onError={e => { e.currentTarget.style.display = 'none'; }}/>
                : <div className="avatar">{initials}</div>}
              <div className="user-data"><h2>{fullName || telegramUser.username || `ID ${telegramUser.id}`}</h2><b>{telegramUser.username ? `@${telegramUser.username}` : (lang === 'EN' ? 'Username not set' : 'Имя пользователя не задано')}</b><small>TELEGRAM ID&nbsp; {telegramUser.id}</small></div>
            </div>
            <div className="profile-stats">
              <div><small>{t.balance}</small><b>—</b></div><div><small>{t.spent}</small><b>—</b></div>
              <div><small>{t.purchases}</small><b>—</b></div>
              <div className="language-stat"><small>{t.language}</small><button onClick={() => setLang(lang === 'EN' ? 'RU' : 'EN')}>{lang}<ChevronDown size={15}/></button></div>
            </div>
            {telegramUser.is_premium && <div className="premium-chip"><Gem size={14}/>{t.premium}</div>}
          </> : <div className="telegram-connect">
            <div className="connect-icon"><UserRoundCheck size={26}/></div><h3>{t.notConnected}</h3><p>{t.telegramConnect}</p><a className="primary-btn connect-button" href={botUrl} target="_blank" rel="noreferrer">{t.connect} <ExternalLink size={14}/></a>
          </div>}
          <div className="funds-box"><h3>{t.add}</h3><p>{t.fundSub}</p><div className="fund-actions"><button disabled>＋ Deposit</button><button disabled>↗ Withdraw</button></div></div>
          <a className="bot-card-link" href={botUrl} target="_blank" rel="noreferrer"><span className="bot-avatar"><ShieldCheck size={19}/></span><span><b>@Playerok_Guarantor_Bot</b><small>{t.bot}</small></span><ExternalLink size={15}/></a>
          <button className="admin-entry" onClick={() => go('admin')}><ShieldCheck size={17}/>{t.admin}<ArrowUpRight size={15}/></button>
        </div>
      </section>}

      {tab === 'admin' && <section className="admin-page">
        <div className="admin-header"><button className="back-button" onClick={() => go('profile')}><ArrowLeft size={17}/>{t.back}</button><div className="admin-title"><div><span className="eyebrow">PLAYEROK</span><h1>{t.adminTitle}</h1><p>{t.adminSub}</p></div><div className="heading-icon"><ShieldCheck size={22}/></div></div></div>
        <div className="admin-notice"><Globe2 size={17}/><span>{t.localOnly}</span></div>
        <form className="admin-form panel" onSubmit={addGift}>
          <h2><Plus size={19}/>{t.addGift}</h2>
          <label>{t.collectionName}<input required value={giftForm.collection} onChange={e => updateForm('collection', e.target.value)} placeholder="Jelly Bunny"/></label>
          <label>{t.number}<input required type="number" min="1" step="1" value={giftForm.number} onChange={e => updateForm('number', e.target.value)} placeholder="12779"/></label>
          <div className="admin-field-row"><label>{t.model}<input required value={giftForm.model} onChange={e => updateForm('model', e.target.value)} placeholder="Spring Day"/></label><label>{t.modelRarity}<input value={giftForm.modelRarity} onChange={e => updateForm('modelRarity', e.target.value)} placeholder="0.4%"/></label></div>
          <div className="admin-field-row"><label>{t.background}<input required value={giftForm.backdrop} onChange={e => updateForm('backdrop', e.target.value)} placeholder="Electric Purple"/></label><label>{t.backgroundRarity}<input value={giftForm.backdropRarity} onChange={e => updateForm('backdropRarity', e.target.value)} placeholder="0.83%"/></label></div>
          <div className="admin-field-row"><label>{t.pattern}<input required value={giftForm.symbol} onChange={e => updateForm('symbol', e.target.value)} placeholder="Spider Web"/></label><label>{t.patternRarity}<input value={giftForm.symbolRarity} onChange={e => updateForm('symbolRarity', e.target.value)} placeholder="0.55%"/></label></div>
          <label>{t.imageUrl}<input required type="url" value={giftForm.image} onChange={e => updateForm('image', e.target.value)} placeholder="https://.../gift.webp"/></label>
          <label>{t.nftUrl}<input type="url" value={giftForm.source} onChange={e => updateForm('source', e.target.value)} placeholder="https://t.me/nft/JellyBunny-12779"/></label>
          <button className="primary-btn admin-submit" type="submit"><Plus size={17}/>{t.saveGift}</button>
        </form>
        <section className="admin-list panel">
          <div className="admin-list-title"><h2>{t.catalogList}</h2><span className="count-pill">{catalog.length}</span></div>
          <div className="admin-tools"><button onClick={exportCatalog}><Upload size={15}/>Export JSON</button><label className="import-button"><ImagePlus size={15}/>Import JSON<input type="file" accept="application/json,.json" onChange={e => { importCatalog(e.target.files?.[0]); e.currentTarget.value = ''; }}/></label></div>
          {catalog.map(g => <div className="admin-gift-row" key={g.id}><img src={g.image} alt=""/><span><b>{g.collection} #{g.number}</b><small>{g.model} · {g.backdrop} · {g.symbol}</small></span><button aria-label={`${t.delete} ${g.collection} ${g.number}`} onClick={() => deleteGift(g.id)}><Trash2 size={16}/></button></div>)}
        </section>
      </section>}
    </main>

    {tab !== 'admin' && <nav className="bottom-nav" aria-label="Main navigation">
      {nav.map(item => { const Icon = item.icon; return <button key={item.id} className={tab === item.id ? 'nav-item active' : 'nav-item'} onClick={() => go(item.id)}><Icon size={20}/><span>{lang === 'EN' ? item.label : item.ru}</span></button>; })}
    </nav>}
    <footer className="footer">
      <a href={botUrl} target="_blank" rel="noreferrer">@Playerok_Guarantor_Bot <ExternalLink size={11}/></a>
      <span>Playerok</span>
    </footer>
    {toast && <div className="toast"><CheckCircle2 size={16}/>{toast}</div>}
  </div>;
}

createRoot(document.getElementById('root')!).render(<App/>);
